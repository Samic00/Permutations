﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public class PermutationGenerator
        {
            public static int counter = 0;
            public static void GeneratePermutations(string word, ListBox listBox)
            {
                char[] characters = word.ToCharArray();
                Array.Sort(characters);
                counter = 0;
                GeneratePermutations(characters, 0, characters.Length - 1, listBox);
            }

            private static void GeneratePermutations(char[] characters, int start, int end, ListBox listBox)
            {
                if (start == end)
                {
                    string permutation = new string(characters);
                    if (!listBox.Items.Contains(permutation))
                    {
                        counter++;
                        listBox.Items.Add(counter +" "+ permutation);
                    }

                }
                else
                {
                    for (int i = start; i <= end; i++)
                    {
                        if (IsSwappable(characters, start, i))
                        {
                            Swap(characters, start, i);
                            GeneratePermutations(characters, start + 1, end, listBox);
                            Swap(characters, start, i); 
                        }
                    }
                }
            }

            private static bool IsSwappable(char[] characters, int start, int current)
            {
                for (int i = start; i < current; i++)
                {
                    if (characters[i] == characters[current])
                        return false;
                }
                return true;
            }

            private static void Swap(char[] characters, int i, int j)
            {
                
                char temp = characters[i];
                characters[i] = characters[j];
                characters[j] = temp;
            }
        }
        public long NumberOfPermutations()
        {
            long number = 0, fact = 1, fact1 = 1, number1 = 0, donje = 1;
            string input = textBox1.Text.ToString().ToLower();
            number = input.Length;
            var letterCounts = input.GroupBy(c => c).ToDictionary(g => g.Key, g => g.Count());

            foreach (var entry in letterCounts)
            {
                number1 = entry.Value;
                fact1 = 1;
                for (long i = 1; i <= number1; i++)
                {
                    fact1 = fact1 * i;
                }
                donje = donje * fact1;
            }
            for (long i = 1; i <= number; i++)
            {
                fact = fact * i;
            }
            label1.Text = "Broj permutacija:" + (fact / donje).ToString();
            return (fact / donje);
        }
        private void button1_Click(object sender, EventArgs e)
        {
            NumberOfPermutations();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (NumberOfPermutations() >20000)
            {
                MessageBox.Show("Prevelik broj permutacija za ispis");
            }
            else
            {
                string input = textBox1.Text.ToString().ToLower();
                listBox1.Items.Clear();
                PermutationGenerator.GeneratePermutations(input, listBox1);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            foreach(string c in listBox1.Items)
            {
                string[] a=c.Split(' ');
                if (a[0] == numericUpDown1.Value.ToString())
                {
                    label2.Text = "Permutacija:"+a[1];
                    numericUpDown1.Minimum = 0;
                    numericUpDown1.Maximum = 2;
                }
            }
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            numericUpDown1.Minimum = 0;
            numericUpDown1.Maximum= NumberOfPermutations();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            bool klik = false;
            foreach (string c in listBox1.Items)
            {
                string[] a = c.Split(' ');
                if (a[1] == textBox1.Text.ToString().ToLower())
                {
                    klik = false;
                }
            }
            if (klik)
            {
                button2.PerformClick();
            }
            string perm = "Nema te permutacije";
            foreach (string c in listBox1.Items)
            {
                string[] a = c.Split(' ');
                if (a[1] == textBox2.Text.ToString())
                {
                    perm = "Permutacija N je:"+a[0];
                }
            }
            label3.Text = perm;

        }
    }
}
